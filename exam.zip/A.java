/**
 * 
 */
package egovframework.example.exam;

/**
 * @author user
 *
 */
public class A {
//	[이론]
//1. 스프링 MVC 디자인 패턴에 대해서 설명해주세요 
//	 MVC 디자인 패턴
//     1) M: 모델(폴더) : 데이터 저장 코딩(DB)
//     2) V: 화면에 관련된 코딩(JSP)
//     3) C:  화면과 URL 을 연결하는 코딩
// => 어노테이션 을 적극적으로 활용한 코딩
//      (코딩량이 굉장히 줄어듬)
	
}
