/**
 * 
 */
package egovframework.example.exam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

/**
 * @author user
 *[실습]
* 지시한 사항 외에 코딩은 자유롭게 하세요
2. 아래 코드 중 누락된 부분을 추가하세요
@Log4j2
@Controller
public class DeptController {
//        서비스 가져오기
 * 		@Autowired
        private DeptService deptService; 
...
}
 */
public class B {

}
