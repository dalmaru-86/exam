package com.simplecoding.simpledms.exam;

public class A {
//    1. 스프링의 DI, IOC, AOP에 대해서 설명해주세요
//     DI (Dependency Injection) - 의존성 주입
//     :객체 간의 의존 관계를 외부에서 주입해주는 기법.
//    스프링이 객체를 생성하고 필요한 의존 객체(Bean)를 주입해줍니다.
//     IoC (Inversion of Control) - 제어의 역전
//      :객체 생성과 생명 주기의 제어권을 개발자가 아닌 스프링 컨테이너가 담당하는 개념.
//      즉, 객체를 우리가 new로 직접 만드는 게 아니라, 스프링이 대신 만들어서 관리하고, 필요할 때 꺼내 씁니다.
//    AOP (Aspect-Oriented Programming) - 관점 지향 프로그래밍
//    :로직 중에서 **공통된 부가 기능 (횡단 관심사)**을 분리해서 관리하는 기법
//    (→ 핵심 비즈니스 로직과 공통 기능을 분리)
}
