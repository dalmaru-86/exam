package com.simplecoding.simpledms.exam;

import com.simplecoding.simpledms.dept.service.DeptService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;

//2. 생성자 DI와 컨트롤러를 만들려고 합니다.
//아래 코드 중 누락된 부분을 추가하세요
public class B {
    @Controller
    @RequiredArgsConstructor
    public class DeptController {
        //        서비스 가져오기
        private final DeptService deptService;

    }
}
