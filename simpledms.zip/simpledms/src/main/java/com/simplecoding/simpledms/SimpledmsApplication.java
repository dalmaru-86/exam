package com.simplecoding.simpledms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpledmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpledmsApplication.class, args);
	}

}
