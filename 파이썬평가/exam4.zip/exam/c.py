# 3.https://www.saucedemo.com/ 접속및 로그인 후 나오는 첫페이지에서 상품설명을 모두 크롤링해서 화면에 표시하는 코딩을 하세요

import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=Options())

driver.get("https://www.saucedemo.com/")

# 아이디
driver.find_element(By.CSS_SELECTOR, "#user-name").send_keys("standard_user")
# 암호
driver.find_element(By.CSS_SELECTOR, "#password").send_keys("secret_sauce")
# 버튼 클릭
driver.find_element(By.CSS_SELECTOR, "input[type='submit']").click()

time.sleep(1)

t=driver.find_elements(By.CSS_SELECTOR, ".inventory_item_name ")

for i in range(len(t)):
    y=t[i].text
    print(y)

driver.quit()